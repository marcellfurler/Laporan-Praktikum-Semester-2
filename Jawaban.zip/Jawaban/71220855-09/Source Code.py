### Nomor 1
def campuran_warna_primer(inputan, inputan2):
    if (inputan==warna_primer[0] and inputan2==warna_primer[0]):
        print(f"Warna yang dihasilkan dari warna {inputan} dan warna {inputan2} adalah warna '{warna_primer[0]}'")
    elif (inputan==warna_primer[1] and inputan2==warna_primer[1]):
        print(f"Warna yang dihasilkan dari warna {inputan} dan warna {inputan2} adalah warna '{warna_primer[1]}'")
    elif (inputan==warna_primer[2] and inputan2==warna_primer[2]):
        print(f"Warna yang dihasilkan dari warna {inputan} dan warna {inputan2} adalah warna '{warna_primer[2]}'")
    elif (inputan==warna_primer[0] and inputan2==warna_primer[1]) or (inputan==warna_primer[1] and inputan2==warna_primer[0]) :
        print(f"Warna yang dihasilkan dari warna {inputan} dan warna {inputan2} adalah warna '{warna_sekunder[0]}'")
    elif (inputan==warna_primer[0] and inputan2==warna_primer[2]) or (inputan==warna_primer[2] and inputan2==warna_primer[0]):
        print(f"Warna yang dihasilkan dari warna {inputan} dan warna {inputan2} adalah warna '{warna_sekunder[2]}'")
    elif (inputan==warna_primer[1] and inputan2==warna_primer[2]) or (inputan==warna_primer[2] and inputan2==warna_primer[1]):
        print(f"Warna yang dihasilkan dari warna {inputan} dan warna {inputan2} adalah warna '{warna_sekunder[1]}'")
    else:
        print("Warna yang anda masukan mungkin bukanlah warna primer")

def campuran_warna_primer_sekunder(inputan, inputan2):
    if inputan==warna_primer[0] and inputan2==warna_sekunder[1]:
        print(f"Warna yang dihasilkan dari warna {inputan} dan warna {inputan2} adalah warna '{warna_tersier[0]}'")
    elif inputan==warna_primer[1] and inputan2==warna_sekunder[2] :
        print(f"Warna yang dihasilkan dari warna {inputan} dan warna {inputan2} adalah warna '{warna_tersier[1]}'")
    elif inputan==warna_primer[2] and inputan2==warna_sekunder[0]:
        print(f"Warna yang dihasilkan dari warna {inputan} dan warna {inputan2} adalah warna '{warna_tersier[2]}'")
    elif inputan==warna_primer[0] and inputan2==warna_sekunder[2]:
        print(f"Warna yang dihasilkan dari warna {inputan} dan warna {inputan2} adalah warna '{warna_tersier[3]}'")
    elif inputan==warna_primer[0] and inputan2==warna_sekunder[0]:
        print(f"Warna yang dihasilkan dari warna {inputan} dan warna {inputan2} adalah warna '{warna_tersier[4]}'")
    elif inputan==warna_primer[0] and inputan2==warna_sekunder[1]:
        print(f"Warna yang dihasilkan dari warna {inputan} dan warna {inputan2} adalah warna '{warna_tersier[5]}'")
    elif inputan==warna_primer[2] and inputan2==warna_sekunder[2]:
        print(f"Warna yang dihasilkan dari warna {inputan} dan warna {inputan2} adalah warna '{warna_tersier[6]}'")
    elif inputan==warna_primer[2] and inputan2==warna_sekunder[1]:
        print(f"Warna yang dihasilkan dari warna {inputan} dan warna {inputan2} adalah warna '{warna_tersier[7]}'")
    elif inputan==warna_primer[1] and inputan2==warna_sekunder[1]:
        print(f"Warna yang dihasilkan dari warna {inputan} dan warna {inputan2} adalah warna '{warna_tersier[8]}'")
    else:
        print("Warna yang anda masukan mungkin bukanlah warna primer ataupun sekunder")


warna_primer=["merah" , "kuning" , "biru"]
warna_sekunder=["oranye", "hijau" , "ungu"]
warna_tersier=["coklat kemerahan", "coklat kekuningan", "coklat kebiruan", "merah keunguan", "oranye kemerahan", "orange kekuningan", "biru keunguan", "biru kehijauan", "kuning kehijauan"]


print("Selamat Datang di Kalkulator Pencampur Warna RGB\nWarna Primer : merah, kuning, dan biru\nWarna Sekunder : Oranye, Hijau dan ungu")
print("1. Kalkulator warna Sekunder (primer+primer=sekunder)")
print("2. Kalkulator warna Tersier (Primer+sekunder=tersier)")
print("3. Ketik 'ex' untuk exit dari program")
pilihan=input("Masukan pilihan anda : ")

while True:
    if pilihan=="1":
        inputan=input("Masukan warna primer : ")
        inputan2=input("Masukan warna primer : ")
        campuran_warna_primer(inputan, inputan2)
        exit1=input("Ketik 'ex' jika ingin keluar dari program (ketik '1' jika lanjut):  ")
        if exit1=="1":
            continue
        else:
            break
    elif pilihan=="2":
        inputan=input("Masukan warna primer : ")
        inputan2=input("Masukan warna sekunder : ")
        campuran_warna_primer_sekunder(inputan, inputan2)
        exit2=input("Ketik 'ex' jika ingin keluar dari program (ketik '1' jika lanjut):  ")
        if exit2=="1":
            continue
        else:
            break
    elif pilihan=="3":
        break
    else:
        print("Ada kesalahan inputan, coba lagi!")
        break


### Nomor 2
def mean(nilai):
    total = sum(nilai)
    rata_rata = total / len(nilai)
    return rata_rata


nama_mahasiswa=["Joko Widodo", "Megawati", "Sri Mulyani", "Jusuf Kalla", "Prabowo Subianto", "Soekarno"]

nama_mahasiswa=list(map(str.lower, nama_mahasiswa))

nama=input("Masukan nama anda : ")

for a in nama_mahasiswa:
    if nama not in nama_mahasiswa:
        print("Nama yang anda inputkan bukan mahasiswa IndoJaya!")
        break
    else :
        continue

    
banyak_nilai = int(input("Masukkan banyak nilai yang ingin diinputkan : "))


nilai_siswa = []
for i in range(banyak_nilai):
    nilai = int(input("Masukkan nilai siswa: "))
    nilai_siswa.append(nilai)


rata_rata_nilai = mean(nilai_siswa)
print(f"Hello {nama}! Rata-rata nilai anda adalah:", rata_rata_nilai)


### Nomor 3
def data_diri_nim(inputan_nim):
    for banyak in range(len(nim)):
        if inputan_nim in nim[banyak]:
            no_induk=nim.index(inputan_nim)
            print(f"Nama mahasiswa\t\t\t: {nama_mahasiswa[banyak]}\nNomor Induk Mahasiswa\t\t: {nim[banyak]}\nJurusan Kuliah\t\t\t: {nama_prodi[banyak]}\nTanggal Lahir\t\t\t: {kode_tanggal_lahir[banyak]}\nTahun Lahir\t\t\t: {kode_tahun_lahir[banyak]}")
            break
    else:
        print(f"Data yang anda masukan, yaitu {inputan_nim} belum terdaftar, atau bukan mahasiswa Universitas Indojaya")

def data_diri_nama(inputan_nama):
    for banyak in range(len(nama_mahasiswa)):
        if inputan_nama in nama_mahasiswa[banyak]:
            mahasiswa=nama_mahasiswa.index(inputan_nama)
            print(f"Nama mahasiswa\t\t\t: {nama_mahasiswa[banyak]}\nNomor Induk Mahasiswa\t\t: {nim[banyak]}\nJurusan Kuliah\t\t\t: {nama_prodi[banyak]}\nTanggal Lahir\t\t\t: {kode_tanggal_lahir[banyak]}\nTahun Lahir\t\t\t: {kode_tahun_lahir[banyak]}")
            break
    else:
        print(f"Data yang anda masukan, yaitu {inputan_nama} belum terdaftar, atau bukan mahasiswa Universitas Indojaya")
       



nama_mahasiswa=["Joko Widodo", "Megawati", "Sri Mulyani", "Jusuf Kalla", "Prabowo Subianto", "Soekarno"]
nim=["11211961", "33231947", "33261962", "11151942", "22171951", "33061901"]

nama_mahasiswa=list(map(str.lower, nama_mahasiswa))

kode_prodi=[]
for prodi in nim:
    kode_prodi.append(prodi[0:2])

nama_prodi=[]
for prodi in kode_prodi:
    if prodi=="11":
        nama_prodi.append("Matematika")
    elif prodi=="22":
        nama_prodi.append("Komputer")
    elif prodi=="33":
        nama_prodi.append("Bisnis")

kode_tanggal_lahir=[]
for tanggal_lahir in nim:
    kode_tanggal_lahir.append(tanggal_lahir[2:4])
kode_tahun_lahir=[]
for tahun_lahir in nim:
    kode_tahun_lahir.append(tahun_lahir[4:8])


print("Selamat Datang di Universitas IndoJaya!\nSekarang Anda berada di mesin Pencari data Mahasiswa")
print("NIM Mahasiswa terdiri dari 8 angka dan memiliki kode khusus, 2 angka pertama yaitu 'kode mata kuliah', 2 angka kedua yaitu 'kode tanggal lahir' dan 4 angka terakhir yaitu 'kode tahun lahir' ")
inputan_masuk=input("Anda ingin mencari data mahasiswa berdasarkan (ketik nim atau nama) : ")



while True:
    if inputan_masuk=="nim":
        inputan_nim=input("Masukan NIM Mahasiswa yang ingin dicari : ")
        data_diri_nim(inputan_nim)
        inputan_lanjut=input("Apakah anda ingin lanjut? Jika masih, ketik 'ya' dan 'ex' untuk berhenti : ")
        if inputan_lanjut=="ya":
            continue
        else:
            break
    elif inputan_masuk=="nama":
        inputan_nama=input("Masukan Nama Mahasiswa yang ingin dicari : ")
        data_diri_nama(inputan_nama)
        inputan_lanjut=input("Apakah anda ingin lanjut? Jika masih, ketik 'ya' dan 'ex' untuk berhenti : ")
        if inputan_lanjut=="ya":
            continue
        else:
            break
    else:
        print("Ada kesalahan Input!")
        break