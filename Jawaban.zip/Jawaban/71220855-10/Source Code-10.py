pajak_impor_ekspor={
    "impor asia" : 0.20,
    "impor eropa" : 0.30,
    "impor oseania" : 0.50,
    "impor amerika" : 0.45,
    "impor afrika" : 0.60,
    "ekspor asia" : 0.10,
    "ekspor eropa" : 0.20,
    "ekspor oseania" : 0.40,
    "ekspor amerika" : 0.35,
    "ekspor afrika" : 0.50
}
negara={
    "asia":["jepang", "china", "singapura", "thailand", "indonesia", "malaysia", "brunei darussalam", "taiwan", "korea selatan", "india", "vietnam", "filipina", "israel", "arab"],
    "eropa":["belanda", "inggris", "prancis", "luksembourgh", "belgia", "jerman" , "swiss" , "finlandia", "norwegia", "russia", "italia", "denmark"],
    "oseania": ["australia", "selandia baru", "papua nugini", ],
    "amerika":["amerika serikat", "kanada", "meksiko", "brasil", "venezuela", "nikaragua", "guatemala", "argentina", "chili"],
    "afrika":["mesir", "afrika selatan", "ghana", "maroko", "pantai gading", "niger", "nigeria", ]
}

mata_uang={
    "dollar singapura" : 11_087, # pembayaran tujuan asia
    "poundsterling" : 18_478, # pembayara tujuan inggris 
    "euro" : 15_929, # pembayaran tujuan eropa
    "dollar australia" : 9_883, # Pembayaran tujuan oseania
    "dollar amerika" : 14_844, #pembayaran tujuan amerika
    "rand afrika selatan":763 # pembayaran tujuan afrika
}

print("Selamat datang di Shokopedia! Kami melayani pembayaran barang impor dan ekspor dengan harga yang sesuai dengan peraturan pemerintah!\nSilahkan masukan pilihan untuk mengekspor atau mengimpor barang!")

print("1. Ekspor Barang\n2. Impor Barang\n3. Exit!")
inputan_pilihan=int(input("Pilihan anda : "))

if inputan_pilihan==1:
    print("Harga ekspor barang yaitu :\n1. SGD.20/kg untuk tujuan daratan Asia\n2. GBP.70/kg untuk tujuan Inggris\n3. EUR.45/kg untuk tujuan daratan Eropa\n4. AUD.40/kg untuk tujuan kepualuan Oseania\n5. USD.50/kg untuk tujuan daratan Amerika\n6. ZAR.700/kg untuk tujuan daratan Afrika")
    print("Jenis Barang yang di ekspor\n1. Makanan\n2. Barang pecah belah\n3. Barang Tahan Banting")
    inputan_jenis_barang=int((input("Masukan Jenis barang : ")))
    if inputan_jenis_barang==1 or 2 or 3:
        barang1=input("Masukan nama barang : ")
    print(f"Terima kasih telah memasukan data anda. Barang anda yaitu '{barang1}' sedang diproses. Silahkan memasukan data selanjutnya!")
    print("Berikut adalah benua tujuan ekspor yang tersedia : asia, eropa, oseania, amerika, afrika")
    tujuan_benua=input("Masukan tujuan benua ekspor barang : ")
    if tujuan_benua=="asia":
        for asia in negara["asia"]:
            print(asia)
    elif tujuan_benua=="eropa":
        for eropa in negara["eropa"]:
            print(eropa)
    elif tujuan_benua=="oseania":
        for oseania in negara["oseania"]:
            print(oseania)
    elif tujuan_benua=="amerika":
        for amerika in negara["amerika"]:
            print(amerika)
    elif tujuan_benua=="afrika":
        for afrika in negara["afrika"]:
            print(afrika)
    tujuan_negara=input("Masukan tujuan negara : ")
    print(f"Tujuan ekspor anda adalah ke benua {tujuan_benua} dan ke negara {tujuan_negara}")           
    berat_barang=float(input("Masukan berat barang yang ingin diekspor (kilogram): "))
    if tujuan_negara in negara["asia"]:
        harga=(berat_barang*(mata_uang["dollar singapura"]*20)) #sgd 20 adalah harga tujuan per kg
        harga_ekspor_asia=(harga*pajak_impor_ekspor["ekspor asia"])+harga
        print(f"Harga awal sebelum terkena pajak adalah : Rp.{harga}")
        print(f"Harga yang anda harus bayar setelah terkena pajak adalah Rp.{harga_ekspor_asia}")
    elif tujuan_negara in negara["eropa"][1]:
        harga=(berat_barang*(mata_uang["poundsterling"]*70)) # GBP 70 adalah harga tujuan per kg
        harga_ekspor_inggris=(harga*pajak_impor_ekspor["ekspor eropa"])+harga
        print(f"Harga awal sebelum terkena pajak adalah : Rp.{harga}")
        print(f"Harga yang anda harus bayar setelah terkena pajak adalah Rp.{harga_ekspor_inggris}")
    elif tujuan_negara in negara["eropa"]:
        harga=(berat_barang*(mata_uang["euro"]*45)) # EUR 45 adalah harga tujuan per kg
        harga_ekspor_eropa=(harga*pajak_impor_ekspor["ekspor eropa"])+harga
        print(f"Harga awal sebelum terkena pajak adalah : Rp.{harga}")
        print(f"Harga yang anda harus bayar setelah terkena pajak adalah Rp.{harga_ekspor_eropa}")
    elif tujuan_negara in negara["oseania"]:
        harga=(berat_barang*(mata_uang["dollar australia"]*40)) # AUD 40 adalah harga tujuan per kg
        harga_ekspor_oseania=(harga*pajak_impor_ekspor["ekspor oseania"])+harga
        print(f"Harga awal sebelum terkena pajak adalah : Rp.{harga}")
        print(f"Harga yang anda harus bayar setelah terkena pajak adalah Rp.{harga_ekspor_oseania}")
    elif tujuan_negara in negara["amerika"]:
        harga=(berat_barang*(mata_uang["dollar amerika"]*50)) # USD 50 adalah harga tujuan per kg
        harga_ekspor_amerika=(harga*pajak_impor_ekspor["ekspor amerika"])+harga
        print(f"Harga awal sebelum terkena pajak adalah : Rp.{harga}")
        print(f"Harga yang anda harus bayar setelah terkena pajak adalah Rp.{harga_ekspor_amerika}")
    elif tujuan_negara in negara["afrika"]:
        harga=(berat_barang*(mata_uang["rand afrika selatan"]*700)) # EUR 45 adalah harga tujuan per kg
        harga_ekspor_afrika=(harga*pajak_impor_ekspor["ekspor afrika"])+harga
        print(f"Harga awal sebelum terkena pajak adalah : Rp.{harga}")
        print(f"Harga yang anda harus bayar setelah terkena pajak adalah Rp.{harga_ekspor_afrika}")
    else:
        print(f"Negara yang anda inputkan, yaitu {tujuan_negara} tidak terdaftar!")

elif inputan_pilihan==2:
    print("Jenis Barang yang di impor\n1. Makanan\n2. Barang pecah belah\n3. Barang Tahan Banting")
    inputan_jenis_barang=int((input("Masukan Jenis barang : ")))
    if inputan_jenis_barang==1 or 2 or 3:
        barang1=input("Masukan nama barang : ")
    print(f"Terima kasih telah memasukan data anda. Barang anda yaitu '{barang1}' sedang diproses. Silahkan memasukan data selanjutnya!")
    print("Berikut adalah benua asal impor yang tersedia : asia, eropa, oseania, amerika, afrika")
    asal_benua=input("Masukan asal benua impor barang : ")
    if asal_benua=="asia":
        for asia in negara["asia"]:
            print(asia)
    elif asal_benua=="eropa":
        for eropa in negara["eropa"]:
            print(eropa)
    elif asal_benua=="oseania":
        for oseania in negara["oseania"]:
            print(oseania)
    elif asal_benua=="amerika":
        for amerika in negara["amerika"]:
            print(amerika)
    elif asal_benua=="afrika":
        for afrika in negara["afrika"]:
            print(afrika)
    asal_negara=input("Masukan asal negara : ")
    harga_barang=int(input("Masukan Harga barang (dalam rupiah): "))
    if asal_negara in negara["asia"]:
        harga=(harga_barang*pajak_impor_ekspor["impor asia"])+harga_barang
        print(f"Harga barang anda sebelum kena pajak dari negara {asal_negara} adalah Rp.{harga_barang}")
        print(f"Harga barang anda setelah kena pajak adalah Rp.{harga}")
    elif asal_negara in negara["eropa"]:
        harga=(harga_barang*pajak_impor_ekspor["impor eropa"])+harga_barang
        print(f"Harga barang anda sebelum kena pajak dari negara {asal_negara} adalah Rp.{harga_barang}")
        print(f"Harga barang anda setelah kena pajak adalah Rp.{harga}")
    elif asal_negara in negara["oseania"]:
        harga=(harga_barang*pajak_impor_ekspor["impor oseania"])+harga_barang
        print(f"Harga barang anda sebelum kena pajak dari negara {asal_negara} adalah Rp.{harga_barang}")
        print(f"Harga barang anda setelah kena pajak adalah Rp.{harga}")
    elif asal_negara in negara["amerika"]:
        harga=(harga_barang*pajak_impor_ekspor["impor amerika"])+harga_barang
        print(f"Harga barang anda sebelum kena pajak dari negara {asal_negara} adalah Rp.{harga_barang}")
        print(f"Harga barang anda setelah kena pajak adalah Rp.{harga}")
    elif asal_negara in negara["afrika"]:
        harga=(harga_barang*pajak_impor_ekspor["impor afrika"])+harga_barang
        print(f"Harga barang anda sebelum kena pajak dari negara {asal_negara} adalah Rp.{harga_barang}")
        print(f"Harga barang anda setelah kena pajak adalah Rp.{harga}")
elif inputan_pilihan==3:
    print("Terima Kasih telah Masuk ke Layanan Kami!")
    exit
else:
    print("Ada Kesalahan Input!")

