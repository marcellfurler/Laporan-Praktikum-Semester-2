p1=int(input("Masukan P1 : "))
p2=int(input("Masukan P2 : "))
p3=int(input("Masukan P3 : "))

# if p1 ==21:
#     p1=("P1")
#     print(f"{p1} adalah pemenang")
# elif p2 ==21:
#     p2=("P2")
#     print(f"{p2} adalah pemenang")
# elif p3 ==21:
#     p3=("P3")
#     print(f"{p3} adalah pemenang")
# # else:
# #     print("Tidak ada yang menang")

# if 15<=p1 <=21:
#     p1=("P1")
#     print(f"{p1} adalah pemenang")
# elif 15<=p2 <=21:
#     p2=("P2")
#     print(f"{p2} adalah pemenang")
# elif 15<=p3 <=21:
#     p3=("P3")
#     print(f"{p3} adalah pemenang")
# else:
#     print("Tidak ada yang menang")

# if p1 >21:
#     p1=("P1")
#     print(f"{p1} Tidak ada pemenang")
# elif p2 >21:
#     p2=("P2")
#     print(f"{p2} Tidak ada pemenang")
# elif p3 >21:
#     p3=("P3")
#     print(f"{p3} Tidak ada pemenang")
# # else:
# #     print("Tidak ada yang menang")

if p1>21 and p2>21 and p3>21:
    print("Tidak ada pemenang")
elif p1==p2==p3:
    print("Tidak ada pemenang")
elif p1<=21 and p1>21 and p1>p3:
    print("Pemenang adalah P1")
elif p2<=21 and p2>p1 and p2>p3:
    print("Pemenang adalah P2")
elif p3<=21 and p3>p1 and p3>p3:
    print("Pemenang adalah P2")
elif p1<=21 and abs(21-p1)<abs(21-p2) and abs(21-p1)<abs(21-p3):
    print("Pemenang adalah P1")
elif p2<=21 and abs(21-p2)<abs(21-p1) and abs(21-p2)<abs(21-p3):
    print("Pemenang adalah P2")
elif p3<=21 and abs(21-p3)<abs(21-p1) and abs(21-p3)<abs(21-p2):
    print("Pemenang adalah P3")
else:
    print("Tidak ada pemenang")