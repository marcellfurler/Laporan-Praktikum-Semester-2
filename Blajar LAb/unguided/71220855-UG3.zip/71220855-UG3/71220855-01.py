jarak=int(input("Masukan Jarak : "))
batas=int(input("Masukan Batas : "))
nilai=int(input("Masukan Nilai : "))

batas_aminus=batas-jarak
batas_bples=batas_aminus-jarak
batas_b=batas_bples-jarak
batas_bminus=batas_b-jarak
batas_cples=batas_bminus-jarak
batas_c=batas_cples-jarak
batas_d=batas_c-jarak
batas_e=batas_d-jarak

# otput

if nilai>=batas:
    print("A")
elif nilai>=batas_aminus:
    print("A-")
elif nilai>=batas_bples:
    print("B+")
elif nilai>=batas_b:
    print("B")
elif nilai>=batas_bminus:
    print("B-")
elif nilai>=batas_cples:
    print("C+")
elif nilai>=batas_c:
    print("C")
elif nilai>=batas_d:
    print("D")
else:
    print("E")