nilai_dadu1=int(input("Masukan nilai dadu pertama (1-6) : "))
nilai_dadu2=int(input("Masukan nilai dadu kedua (1-6) : "))
nilai_dadu3=int(input("Masukan nilai dadu ketiga (1-6) : "))

if nilai_dadu1+nilai_dadu2+nilai_dadu3==18:
    royal=("Royal")
    print(f"Hasilnya adalah {royal}")
elif nilai_dadu1==nilai_dadu2==nilai_dadu3:
    triple=("Triple")
    print(f"Hasil anda adalah {triple}")
elif nilai_dadu1==4 and nilai_dadu2==5 and nilai_dadu3==6:
    flush=("Flush")
    print(f"Hasil anda adalah {flush}")
elif nilai_dadu1==nilai_dadu2 or nilai_dadu2==nilai_dadu3 or nilai_dadu3==nilai_dadu1:
    double=("Double")
    print(f"Hasil anda adalah {double}")
else:
    single="single"
    print(f"Hasil anda adalah {single}")
